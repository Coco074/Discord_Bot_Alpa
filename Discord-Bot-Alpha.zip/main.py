import discord
import os
from keep_alive import keep_alive
from discord.ext import commands
import random
import string

my_secret = os.environ['DISCORD_BOT_SECRET']


bot = commands.Bot(
	command_prefix="!",  # Change to desired prefix
	case_insensitive=True  # Commands aren't case-sensitive
)

bot.author_id = 209472658599837696  # Change to your discord id!!!


def get_alpha():
  response = random.randint(0,100)
  intstring= str(response)
  answer= 'You are ' +intstring+ '% alpha'
  return(answer)
  
  



@bot.event 
async def on_ready():  # When the bot is ready
    print("I'm in")
    print(bot.user)  # Prints the bot's username and identifier

@bot.event
async def on_message(message):
  if message.author == bot.author_id:
    return

  if message.content.startswith('!alpha'):
    answer=get_alpha()
    
  
    
    embedVar=discord.Embed(title= 'Alpha Calculator', description=answer, colour= discord.Colour.blue())
    embedVar.set_thumbnail(url='https://cdn.discordapp.com/attachments/926161669573460061/926181027305627679/giga_chad.jpg')
    
    
    
   
    await message.channel.send(embed=embedVar)

  


extensions = [
	'cogs.cog_example'  # Same name as it would be if you were importing it
]

if __name__ == '__main__':  # Ensures this is the file being ran
	for extension in extensions:
		bot.load_extension(extension)  # Loades every extension.

keep_alive()  # Starts a webserver to be pinged.
token = os.environ.get("DISCORD_BOT_SECRET") 
bot.run(token)  # Starts the bot